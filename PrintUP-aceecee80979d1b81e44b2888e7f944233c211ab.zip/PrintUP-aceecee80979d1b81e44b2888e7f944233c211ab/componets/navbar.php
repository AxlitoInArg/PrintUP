<div class="navbar">
    <a href="index.php" data-label="Inicio"><i class="fa-solid fa-comments"></i> Inicio</a>
    <a href="noti.php" data-label="Notificaciones"><i class="fas fa-bell"></i> Notificaciones</a>
    <a href="configuracion.php" data-label="Configuración"><i class="fas fa-cog"></i> Configuración</a>
</div>