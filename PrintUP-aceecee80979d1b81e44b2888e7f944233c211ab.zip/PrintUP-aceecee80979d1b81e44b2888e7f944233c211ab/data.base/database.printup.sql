DROP DATABASE `printup`;

CREATE DATABASE `printup`;

use `printup`

CREATE TABLE `usuarios` (
    `DNI_Usuario` int(11) NOT NULL PRIMARY KEY,
    `Nombres` varchar(100) NOT NULL,
    `Apellidos` varchar(100) NOT NULL,
    `Edad` int(150) NOT NULL,
    `Email` varchar(100) NOT NULL UNIQUE KEY,
    `Contrasena` varchar(50) NOT NULL,
    `Telefono` varchar(20) NOT NULL,
    `perfil_img` varchar(500) NOT NULL
);

CREATE TABLE `alumnos` (
    `ID_Alumno` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `FK_DNI_Usuario` int(11) DEFAULT NULL,
    `Curso` varchar(50) NOT NULL,
    `Preceptor` varchar(200) NOT NULL,
    FOREIGN KEY (`FK_DNI_Usuario`) REFERENCES `usuarios` (DNI_Usuario)
);

CREATE TABLE `kiosqueros` (
    `ID_Kiosquero` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `FK_DNI_Usuario` int(11) DEFAULT NULL,
    FOREIGN KEY (`FK_DNI_Usuario`) REFERENCES `usuarios` (DNI_Usuario)
);

CREATE TABLE `mensajes` (
    `ID_Mensaje` int(11) NOT NULL PRIMARY KEY AUTO_INCREMENT,
    `FK_DNI_Usuario` int(11) DEFAULT NULL,
    `ID_Kiosquero` int(11) DEFAULT NULL,
    `Fecha_Hora` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
    `Mensaje` text DEFAULT NULL,
    `Autor` BIT(1) DEFAULT NULL,
    FOREIGN KEY (`FK_DNI_Usuario`) REFERENCES `usuarios` (DNI_Usuario),
    FOREIGN KEY (`ID_Kiosquero`) REFERENCES `kiosqueros` (ID_Kiosquero)
);

INSERT INTO
    `usuarios` (
        `DNI_Usuario`,
        `Nombres`,
        `Apellidos`,
        `Edad`,
        `Email`,
        `Contrasena`,
        `Telefono`,
        `perfil_img`
    )
VALUES (
        '45931135',
        'carlos daniel',
        'soliz siles',
        '19',
        'carlos.soliz.t1vl@gmail.com',
        '1234',
        '01122529318',
        'image.defaul.webp'
    ),
    (
        '42931135',
        'natalia',
        'natalia',
        '17',
        'tamara.fernandez.t1vl@gmail.com',
        '1234',
        '01142623361',
        'image.natalia.webp'
    );

INSERT INTO
    `alumnos` (
        `FK_DNI_Usuario`,
        `Curso`,
        `Preceptor`
    )
VALUES (
        '45931135',
        '7mo 2da',
        'Javier Milei'
    );

INSERT INTO
    `kiosqueros` (`FK_DNI_Usuario`)
VALUES ('42931135');

-- Insertamos 10 usuarios
INSERT INTO
    `usuarios` (
        `DNI_Usuario`,
        `Nombres`,
        `Apellidos`,
        `Edad`,
        `Email`,
        `Contrasena`,
        `Telefono`,
        `perfil_img`
    )
VALUES (
        1,
        'Usuario',
        'Uno',
        30,
        'usuario1@email.com',
        'contrasena1',
        '1111111111',
        'image.defaul.webp'
    ),
    (
        2,
        'Usuario',
        'Dos',
        31,
        'usuario2@email.com',
        'contrasena2',
        '2222222222',
        'image.defaul.webp'
    ),
    (
        3,
        'Usuario',
        'Tres',
        32,
        'usuario3@email.com',
        'contrasena3',
        '3333333333',
        'image.defaul.webp'
    ),
    (
        4,
        'Usuario',
        'Cuatro',
        33,
        'usuario4@email.com',
        'contrasena4',
        '4444444444',
        'image.defaul.webp'
    ),
    (
        5,
        'Usuario',
        'Cinco',
        34,
        'usuario5@email.com',
        'contrasena5',
        '5555555555',
        'image.defaul.webp'
    ),
    (
        6,
        'Usuario',
        'Seis',
        35,
        'usuario6@email.com',
        'contrasena6',
        '6666666666',
        'image.defaul.webp'
    ),
    (
        7,
        'Usuario',
        'Siete',
        36,
        'usuario7@email.com',
        'contrasena7',
        '7777777777',
        'image.defaul.webp'
    );

-- Insertamos 2 kiosqueros (los usuarios con DNI 1 y 2)
INSERT INTO
    `kiosqueros` (`FK_DNI_Usuario`)
VALUES (1),
    (2),
    (3),
    (4);

CREATE TABLE `password_resets` (
    `token` varchar(255) NOT NULL PRIMARY KEY,
    `Email` varchar(100) NOT NULL,
    `expires` int(11) NOT NULL,
    FOREIGN KEY (Email) REFERENCES `usuarios` (Email)
);

CREATE TABLE `archivos` (
    `ID_Archivo` int(11) NOT NULL,
    `ID_Mensaje` int(11) DEFAULT NULL,
    `Nombre_Archivo` varchar(255) DEFAULT NULL,
    `Tipo_Archivo` varchar(50) DEFAULT NULL,
    `Tamano_Archivo` int(11) DEFAULT NULL,
    `Ruta_Archivo` VARCHAR(255) NOT NULL,
    FOREIGN KEY (`ID_Mensaje`) REFERENCES `mensajes` (`ID_Mensaje`)
);

-- SELECT u.DNI_Usuario, u.Nombres, u.Apellidos, COUNT(m.ID_Mensaje) as Cantidad_Mensajes
-- FROM `usuarios` u
-- JOIN `kiosqueros` k ON u.DNI_Usuario = k.FK_DNI_Usuario
-- LEFT JOIN `mensajes` m ON k.ID_Kiosquero = m.ID_Kiosquero
-- GROUP BY u.DNI_Usuario, u.Nombres, u.Apellidos;